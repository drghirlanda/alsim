newModel <- function( genFunction, learnRate ) {
    m <- list(
	weights=list(),
	gen=genFunction,
	rate=learnRate,
	trials=c(),
	lambda=c(),
	V0=list()
    )
    class(m) <- "model"
    m
}
