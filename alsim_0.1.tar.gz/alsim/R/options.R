alsim.options <- list(
    rem=list(r=0)
)
